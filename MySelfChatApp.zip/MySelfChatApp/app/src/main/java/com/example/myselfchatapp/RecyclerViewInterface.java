package com.example.myselfchatapp;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
